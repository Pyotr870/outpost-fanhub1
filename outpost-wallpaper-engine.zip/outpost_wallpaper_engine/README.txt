OUTPOST — Wallpaper Engine Web Wallpaper

1. Extract this folder to a dedicated location.
2. Open Wallpaper Engine.
3. Choose Create Wallpaper.
4. Drag main.html onto the Create Wallpaper button.
5. Check the result at your display resolution and ultrawide aspect ratios.
6. To publish, use the Workshop menu in Wallpaper Engine.

The wallpaper is self-contained: it uses local HTML/CSS only and does not fetch remote assets.
This is an unofficial fan-made visual project and is not affiliated with Embark Studios.
